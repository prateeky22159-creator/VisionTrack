# Add alerting logic here (email/Slack). Use APScheduler for periodic checks.
